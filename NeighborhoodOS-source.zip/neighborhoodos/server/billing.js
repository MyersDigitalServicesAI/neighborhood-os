import { Problem } from './supabase.js';

const subscriptionEvents = new Set(['customer.subscription.created','customer.subscription.updated','customer.subscription.deleted',
  'customer.subscription.paused','customer.subscription.resumed']);
const invoiceEvents = new Set(['invoice.paid','invoice.payment_failed','invoice.payment_action_required','invoice.voided','invoice.marked_uncollectible']);

const utf8 = new TextEncoder();
const decode = new TextDecoder();
export async function verifyStripeEvent(raw, signature, secret, seconds = Date.now() / 1000) {
  const pairs = String(signature ?? '').split(',').map((pair) => pair.trim().split('='));
  const stamped = pairs.find(([key]) => key === 't')?.[1];
  if (!/^\d+$/.test(stamped ?? '') || Math.abs(seconds - Number(stamped)) > 300) throw new Problem(400, 'Invalid signature.');
  const prefix = utf8.encode(stamped + '.');
  const content = new Uint8Array(prefix.length + raw.length);
  content.set(prefix);
  content.set(raw,prefix.length);
  const key = await crypto.subtle.importKey('raw',utf8.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);
  for (const [kind,value] of pairs) {
    if (kind !== 'v1' || !/^[0-9a-f]{64}$/i.test(value ?? '')) continue;
    const hash = Uint8Array.from(value.match(/../g),pair=>parseInt(pair,16));
    if (await crypto.subtle.verify('HMAC',key,hash,content)) {
      try { return JSON.parse(decode.decode(raw)); } catch { throw new Problem(400, 'Invalid event.'); }
    }
  }
  throw new Problem(400,'Invalid signature.');
}

export function subscriptionState(sub, priceId, observedAt) {
  const item = sub.items?.data?.length === 1 ? sub.items.data[0] : null;
  const price = item?.price;
  const correctPrice = price?.id === priceId && price.unit_amount === 10000 && price.currency === 'usd' &&
    price.recurring?.interval === 'month' && price.recurring.interval_count === 1 && item.quantity === 1;
  const periodEnd = item?.current_period_end ?? sub.current_period_end;
  const paid = sub.latest_invoice?.status === 'paid' && sub.latest_invoice.amount_paid >= 10000 &&
    sub.latest_invoice.currency === 'usd';
  return {
    business: sub.metadata?.neighborhood_business,
    checkoutKey: sub.metadata?.neighborhood_checkout,
    subscription: sub.id,
    customer: typeof sub.customer === 'string' ? sub.customer : sub.customer?.id,
    active: !!(correctPrice && paid && sub.status === 'active' && !sub.pause_collection && Number.isFinite(periodEnd)),
    paidUntil: Number.isFinite(periodEnd) ? new Date(periodEnd * 1000).toISOString() : null,
    observedAt,
    terminal:['canceled','incomplete_expired'].includes(sub.status)
  };
}

export function billingAdapter(env, database, request = fetch) {
  const { STRIPE_SECRET_KEY: key, STRIPE_PRICE_ID: priceId, STRIPE_WEBHOOK_SECRET: webhookSecret, APP_ORIGIN: origin } = env;
  const enabled = !!(key && priceId && webhookSecret && origin && env.SUPABASE_SECRET_KEY);
  async function stripe(path, params, idempotency) {
    const response = await request('https://api.stripe.com/v1/' + path, {
      method: params ? 'POST' : 'GET',
      headers: { Authorization: 'Bearer ' + key, 'Stripe-Version': '2025-09-30.clover',
        ...(params ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}),
        ...(idempotency ? { 'Idempotency-Key': idempotency } : {}) },
      body: params ? new URLSearchParams(params) : undefined, signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) throw new Problem(502, 'Billing provider is temporarily unavailable.');
    return response.json();
  }
  return {
    enabled,
    async checkout(approval) {
      const price = await stripe('prices/' + encodeURIComponent(priceId));
      if (!price.active || price.unit_amount !== 10000 || price.currency !== 'usd' ||
          price.recurring?.interval !== 'month' || price.recurring.interval_count !== 1) {
        throw new Problem(503, 'The verified business price is unavailable.');
      }
      const session = await stripe('checkout/sessions', {
        mode: 'subscription', 'metadata[neighborhood_business]':approval.id, 'metadata[neighborhood_checkout]':approval.key, 'line_items[0][price]': priceId, 'line_items[0][quantity]': '1',
        success_url: origin + '/#manage', cancel_url: origin + '/#manage',
        'subscription_data[metadata][neighborhood_business]': approval.id,
        'subscription_data[metadata][neighborhood_checkout]': approval.key,
        ...(approval.customer ? { customer: approval.customer } : {})
      }, 'neighborhood-checkout-' + approval.key);
      if (!session.url) throw new Problem(409, 'Checkout is already complete or expired. Check billing status.');
      return { url: session.url };
    },
    async portal(customer) {
      const session = await stripe('billing_portal/sessions', { customer, return_url: origin + '/#manage' });
      return { url: session.url };
    },
    async webhook(raw, signature) {
      if (!enabled) throw new Problem(503, 'Billing is disabled.');
      const event = await verifyStripeEvent(raw, signature, webhookSecret);
      if (event.livemode !== key.startsWith('sk_live_')) throw new Problem(400, 'Billing mode mismatch.');
      const obj = event.data?.object;
      if (event.type === 'checkout.session.expired' && /^cs_[A-Za-z0-9_]+$/.test(obj?.id ?? '')) {
        const observedAt = new Date().toISOString();
        const session = await stripe('checkout/sessions/' + encodeURIComponent(obj.id));
        if (session.status === 'expired' && !session.subscription && session.metadata?.neighborhood_business && session.metadata?.neighborhood_checkout) {
          await database.syncBilling({business:session.metadata.neighborhood_business,checkoutKey:session.metadata.neighborhood_checkout,
            expired:true,observedAt});
        }
        return;
      }
      const subscriptionId = subscriptionEvents.has(event.type) ? obj?.id :
        invoiceEvents.has(event.type) ? obj?.parent?.subscription_details?.subscription ?? obj?.subscription :
        event.type === 'checkout.session.completed' ? obj?.subscription : null;
      if (!/^sub_[A-Za-z0-9]+$/.test(subscriptionId ?? '')) return;
      const observedAt = new Date().toISOString();
      const sub = await stripe('subscriptions/' + encodeURIComponent(subscriptionId) + '?expand[]=latest_invoice');
      const state = subscriptionState(sub, priceId, observedAt);
      if (!state.business || !state.checkoutKey || !state.customer) return;
      await database.syncBilling(state);
    }
  };
}
