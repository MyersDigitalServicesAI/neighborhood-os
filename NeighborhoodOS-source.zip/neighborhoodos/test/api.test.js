import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { makeHandler } from '../server/handler.js';
import { verifyStripeEvent, subscriptionState } from '../server/billing.js';

const origin = 'https://neighborhood.example';
const request = async (handler,action,{method='POST',body={},headers={}}={}) => {
  const data = new TextEncoder().encode(JSON.stringify(body));
  const req = {method,url:'/api/core?action='+action,headers:{origin,'content-type':'application/json',...headers},
    async *[Symbol.asyncIterator](){yield data;}};
  const res = {headers:{},setHeader(k,v){this.headers[k.toLowerCase()]=v;},end(value){this.body=value?JSON.parse(value):null;}};
  await handler(req,res);
  return res;
};
test('app API rejects cross-origin, unauthorized, invalid, and oversized requests',async()=>{
  const handler = makeHandler({env:{APP_ORIGIN:origin},database:{configured:true},billing:{enabled:false}});
  assert.equal((await request(handler,'feed',{headers:{origin:'https://evil.example'}})).statusCode,403);
  assert.equal((await request(handler,'feed')).statusCode,401);
  assert.equal((await request(handler,'feed',{body:'a'.repeat(17000)})).statusCode,413);
  assert.equal((await request(handler,'feed',{body:[]})).statusCode,400);
  assert.equal((await request(handler,'signup',{body:{email:'abc@example.test',password:'valid-long-password'}})).statusCode,403);
});
test('API sets protected session cookies and keeps tokens out of the response body',async()=>{
  const handler = makeHandler({env:{APP_ORIGIN:origin},database:{configured:true,login:async()=>({
    access_token:'access-fixture',refresh_token:'refresh-fixture',expires_in:3600
  })},billing:{enabled:false}});
  const res = await request(handler,'login',{body:{email:'person@example.test',password:'valid-long-password'}});
  assert.equal(res.statusCode,200);
  assert.deepEqual(res.body,{signedIn:true});
  assert.match(res.headers['set-cookie'][0],/^__Host-nh_access=access-fixture; Path=\/; HttpOnly; SameSite=Lax; Max-Age=3600; Secure$/);
  assert.equal(res.headers['cache-control'],'private, no-store');
});
test('verified subscription requires correct price, latest paid invoice and current provider status',()=>{
  const until = Math.floor(Date.now()/1000)+10000;
  const sub = {id:'sub_fixture',customer:'cus_fixture',status:'active',metadata:{neighborhood_business:'b',neighborhood_checkout:'x'},
    latest_invoice:{status:'paid',currency:'usd',amount_paid:10000},
    items:{data:[{quantity:1,current_period_end:until,price:{id:'price_right',currency:'usd',unit_amount:10000,recurring:{interval:'month',interval_count:1}}}]}};
  const state = (change) => subscriptionState({...sub,...change},'price_right',new Date().toISOString());
  assert.equal(state({}).active,true);
  assert.equal(state({latest_invoice:{status:'open',currency:'usd',amount_paid:0}}).active,false);
  assert.equal(state({status:'canceled'}).active,false);
  assert.equal(state({status:'canceled'}).terminal,true);
  assert.equal(subscriptionState(sub,'price_other','now').active,false);
});
test('Stripe signature verifies raw bytes, rejects stale requests, and rejects tampering',async()=>{
  const bytes = new TextEncoder().encode('{"type":"invoice.paid"}');
  const timestamp = 1000;
  const secret = 'fixture-secret';
  const hash = createHmac('sha256',secret).update(timestamp+'.').update(bytes).digest('hex');
  const signature = 't='+timestamp+',v1='+hash;
  assert.deepEqual(await verifyStripeEvent(bytes,signature,secret,timestamp),{type:'invoice.paid'});
  await assert.rejects(verifyStripeEvent(bytes,signature,secret,1400),/Invalid signature/);
  await assert.rejects(verifyStripeEvent(new TextEncoder().encode('{}'),signature,secret,timestamp),/Invalid signature/);
});
